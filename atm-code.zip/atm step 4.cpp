#include <iostream>
using namespace std;
int add(){
int num1,num2;
cout<<"enter num1:";
cin>>num1;
cout<<"enter num2:";
cin>>num2;
cout<<"the addition is :"<<num1+num2;



}
int sub(){
int num1,num2;
cout<<"enter num1:";
cin>>num1;
cout<<"enter num2:";
cin>>num2;
cout<<"the subtraction is :"<<num1-num2;



}
int mul(){
int num1,num2;
cout<<"enter num1:";
cin>>num1;
cout<<"enter num2:";
cin>>num2;
cout<<"the multiplication  is :"<<num1*num2;



}int div(){
int num1,num2;
cout<<"enter num1:";
cin>>num1;
cout<<"enter num2:";
cin>>num2;
cout<<"the division is :"<<num1/num2;

}

int main()
{
int choice;
	cout<<"1-addition\n"<<"2-subtraction\n"<<"3-multiplication\n"<<"4-division\n";
	cout<<"enter your choice\n";
	cin>>choice;
	string operation;
	char op='y';
	while(op!='n'){
		cout<<"Do you perform another operations?(y/n)";
		

	
	switch(choice)
	{
		case 1:
			add();
			break;
		case 2:
				sub();
		break;
		case 3:
			mul();
		break;
			case 4:
			div();
			break;
			default:
				cout<<"enter a invalid no:";
	}
	
}

}
